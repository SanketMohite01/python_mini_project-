from turtle import Turtle, Screen
import time
from players import Player
from manager import Manager
from score import  Score
  

screen = Screen()
player = Player()
manager= Manager()
score = Score()


screen.tracer(0)
screen.title("Turtle Game")
screen.setup(width=600, height=600)

screen.listen()
screen.onkey(player.go_up, "Up")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    manager.create_car()
    manager.move_cars()



    for car in  manager.all_cars:
        if car.distance(player)<20:
            game_is_on=False
            score.game_over()


    

    if player.is_at_finish_line():
        player.go_to_start()
        manager.level_up()
        score.increase_level()




screen.exitonclick()
