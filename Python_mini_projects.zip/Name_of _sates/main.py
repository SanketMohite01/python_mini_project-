from turtle import Turtle, Screen
import pandas


screen = Screen()
screen.setup(width=725, height=491) 
screen.title("U.S. States Game")
screen.bgpic("blank_states_img.gif")


data = pandas.read_csv("50_states.csv")
all_states = data.state.to_list()
guessed_states = []

while len(guessed_states) < 50:
    answer_state = screen.textinput(
        title=f"{len(guessed_states)}/50 States Correct",
        prompt="What's another state's name?"
    )

    if answer_state == None:
        break  

    answer_state = answer_state.title() 
    if answer_state in all_states and answer_state not in guessed_states:
        guessed_states.append(answer_state)
        state_data = data[data.state == answer_state]
        
        t = Turtle()
        t.hideturtle()
        t.penup()
        t.goto(int(state_data.x), int(state_data.y))
        t.write(answer_state, align="center", font=("Arial", 8, "normal"))

screen.mainloop()
