print('!!!!welcome to pizza order!!!!')

size=(input('which size do you want? S,M and L:'))
pepperoni=(input('do you want pepproni on your pizza? Y or N:'))
extra_chesse=(input('Do you want extra chesse on your pizza? Y or N:'))

bill=0
if size=='S':
     bill +=15
elif  size=='M':
    bill +=20
else:
    bill +=25


if pepperoni=='Y':
    if size=='S':
        bill +=2

    else:
        bill +=3


if extra_chesse=='Y':
    bill +=1

print ('Your total bill of your pizza is :',bill)    

    
        
    


