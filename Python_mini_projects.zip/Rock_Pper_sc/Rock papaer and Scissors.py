import random
print('Welcome to Rock Papaer and Scissors')

#choice1=['Rock,Paper,Scissors']
choice_user=int(input('What do you choose?Type 0 for Rock,1 for Paper or 2 for Scissors.'))
choice_comp=(random.randint(0,2))
print('computer choice=',choice_comp)


if choice_user==0 and choice_comp==2:
    print('You win')
elif choice_comp > choice_user:
    print('You loss')
else:
    print('Draw')
    
    


